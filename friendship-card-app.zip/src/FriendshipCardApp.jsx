import React, { useState, useRef } from "react";
import html2canvas from "html2canvas";

export default function FriendshipCardApp() {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [bgColor, setBgColor] = useState("#fef3c7");
  const [image, setImage] = useState(null);
  const cardRef = useRef(null);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) setImage(URL.createObjectURL(file));
  };

  const downloadCard = async () => {
    if (!cardRef.current) return;
    const canvas = await html2canvas(cardRef.current);
    const link = document.createElement("a");
    link.download = "friendship_card.png";
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1 style={{ color: '#ec4899' }}>💝 Friendship Card Maker</h1>
      <input
        placeholder="Friend's Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <br /><br />
      <textarea
        placeholder="Write your message..."
        rows={4}
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <br /><br />
      <label>Background: </label>
      <input type="color" value={bgColor} onChange={(e) => setBgColor(e.target.value)} />
      <br /><br />
      <input type="file" accept="image/*" onChange={handleImageUpload} />
      <br /><br />
      <button onClick={downloadCard}>🎁 Download Card</button>

      <div ref={cardRef} style={{ marginTop: '2rem', backgroundColor: bgColor, padding: '2rem', borderRadius: '1rem' }}>
        {image && <img src={image} alt="Friend" style={{ width: 100, height: 100, borderRadius: '50%' }} />}
        <h2>To: {name || "Your Friend"}</h2>
        <p>{message || "Wishing you a great day! 💖"}</p>
      </div>
    </div>
  );
}